Run python3 launch.py. Requires Python 3 and a browser. No npm, model, API, install or internet needed. PDF backups included.
