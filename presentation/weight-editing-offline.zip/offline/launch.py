#!/usr/bin/env python3
"""Launch the frozen offline publication; no installation or network needed."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os, webbrowser
os.chdir(Path(__file__).parent / 'site')
s=ThreadingHTTPServer(('127.0.0.1', 0), SimpleHTTPRequestHandler)
print('Offline study: http://127.0.0.1:%s/' % s.server_port)
webbrowser.open('http://127.0.0.1:%s/' % s.server_port)
s.serve_forever()
